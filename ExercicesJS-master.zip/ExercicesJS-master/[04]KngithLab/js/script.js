var putter = document.getElementsByClassName('jx-handle')

if( putter !== 0 ){
  console.log( putter[0].style.left )
}
