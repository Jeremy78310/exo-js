var data = {
  'perso_0' : {
    'name' : 'Indila',
    'picture' : 'img/Indila.jpg',
    'picture02':'img/archi.jpg',
    'texte' : [' Je préfère prendre le temps et . Je n\'en ai pas encore l\'expérience mais j\'ai hâte car c\'est une étape magique. Il n\'y aura plus d\'intérmédiaire entre moi et le cœur qui bat en face de moi ',' J\'ai des notions de plusieurs langues. De l\'hindi notamment, de l\'urdu, de l\'algérien et des langues scolaires que l\'on peut apprendre petite. Ce sont des langues que j\'ai côtoyées par mes origines,']
  },

  'perso_1' : {
    'name' : 'journaliste',
    'picture' : 'img/journaliste.jpg',
    'picture03':'img/chouwi.jpg',
    'texte' : ['Bonjour Indila. Je suis une très grand fan de toi, j\'aime toutes les musiques de ton album, tu es une véritable artiste. Je voulais savoir si tu allait faire une tournée..., ',' Est-ce que tu sais parler algérien, car je suis algérienne. Et vas-tu sortir un clip pour Comme un bâteau ?', 'Tu as des origines algériennes,Pour la Coupe du monde, vas-tu soutenir l\'équipe de France ou celle d\'Algérie?']
  }
}
