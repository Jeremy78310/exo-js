var data = {
  'perso_0' : {
    'name' : 'luffy',
    'picture' : 'img/1.jpg',
    'picture02' : ['img/gearsecond.gif','img/luffyesquive.gif'],
    'texte' : ['Regarde quand meme et admire!!!', ' Hey zorro j\ai appris une nouvelle technique tu veux voir ?','GEAR SECOND !!! ...']
    },
  'perso_1' : {
    'name' : 'zorro',
    'picture' : 'img/zoro.png',
    'picture02' : ['img/zoro.gif', 'img/chopper.gif'],
    'texte' : ['Capitaine!','Vite alors !','Non je vais aller au bar!','.....']
  }
}
