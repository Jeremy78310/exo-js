var data = {
  'perso_0' : {
    'name' : 'le daron',
    'picture' : 'https://media.giphy.com/media/3o7TKrpHvJuS3KNrS8/giphy.gif',
    'texte' : ['no money pas dgrand pere','ta des tune ','aller barre toi']
  },
  'perso_1' : {
    'name' : 'Archibalde le pti dla boite',
    'picture' : 'https://media.giphy.com/media/l2JhpzAYL3rnNi3S0/giphy.gif',
    'picture02' :'https://media.giphy.com/media/3o7TKHo2RvR6ZzWxEc/giphy.gif',
    'picture03' :'https://media.giphy.com/media/l2JhpzAYL3rnNi3S0/giphy.gif',
    'texte' : ['Grand père, c\'est moi!','J\'ai pas de tune g 1euro','Pff nimporte quoi!']
  }
}
