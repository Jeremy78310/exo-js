var data = {
  'perso_0' : {
    'name' : 'kobayakawa sena',
    'picture' : 'img/21.jpg',
    'texte' : ['non pas du tout je suis un héro d\'anime','J\'vois pas de quoi tu parles','je reviens hein attend moi la bouge surtout pas']
  },
  'perso_1' : {
    'name' : 'Ladanian Tomlinson',
    'picture' : 'img/LT.jpg',
    'texte' : ['Hey tu me ressemble un peu non ?','uniforme numéro de maillot , eyeshield ca commence a être suspect tout de meme','escroc avoue le plagiat!!']
  }
}
