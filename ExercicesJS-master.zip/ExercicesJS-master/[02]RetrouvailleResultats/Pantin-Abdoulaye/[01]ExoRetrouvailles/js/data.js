var data = {
  'perso_0' : {
    'name' : 'Floyd Mayweather',
    'picture' : 'img/mwthr.jpg',
    'picture01' : 'img/may.jpg',
    'texte' : ["Les morveux comme toi jme les enfiles au ptit dèj",'Surveille ton language jeune avorton','Wataaaaaaaaaaa']
  },
  'perso_1' : {
    'name' : 'Conor McGregor',
    'picture' : 'img/mcgregor.jpg',
    'picture02' : 'img/greg.jpg',
    'texte' : ["c'est moi qu'tu regardes Ducon !?","qu'est-ce qu'on attends pour se mettre sur la tronche",'Un blème ???',"blabla"]
  }
}
