var data = {
  'perso_0' : {
    'name' : 'pong',
    'picture' : 'img/0a.jpg',
    'texte' : ['à toi','pff','on s\'ennuie nan','><']
  },
  'perso_1' : {
    'name' : 'ping',
    'picture' : 'img/0b.jpg',
    'texte' : ['à toi', 'à toi','à toi','perdu']
  }
}
