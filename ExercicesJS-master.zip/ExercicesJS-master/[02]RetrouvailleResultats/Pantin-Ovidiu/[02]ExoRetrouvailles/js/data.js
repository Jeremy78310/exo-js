var data = {
  'perso_0' : {
    'name' : 'Gauche',
    'picture' : 'img/test1.jpg',
    'texte' : ['Slip','mais non slip','SLIIIIP']
  },
  'perso_1' : {
    'name' : 'Droite',
    'picture' : 'img/test.jpg',
    'texte' : ['Calçon','MAIIIIS NON CALEÇON','CALEÇONnnnnn!']
  }
}
