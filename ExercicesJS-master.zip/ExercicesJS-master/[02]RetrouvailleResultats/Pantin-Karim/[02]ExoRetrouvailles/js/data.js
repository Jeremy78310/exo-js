var data = {
  'perso_0' : {
    'name' : 'jerry',
    'picture' : ['img/jerry.gif','img/archi.jpg'],
    'texte' : ['Brouuuuwhaaaaa','Drrrriiiitch','Hinnn Wouaaa']
  },
  'perso_1' : {
    'name' : 'tom',
    'picture' :[ 'img/tom.jpg'],
    'texte' : ['Grand père, c\'est moi!','J\'aime les pâttes moi aussi','Pff nimporte quoi!']
  }
}
