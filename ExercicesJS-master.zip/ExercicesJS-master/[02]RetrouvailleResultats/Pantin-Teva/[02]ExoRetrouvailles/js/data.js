var data = {
  'perso_0' : {
    'name' : 'Messi',
    'picture' : 'img/messi.jpg',
    'picture02': 'img/giphy.gif',
    'texte' : ['Des cotes que je t\'ai félé ou détruit','... T\'oublie super vite mon ami...','Regarde t\'es juste le champion de la glisse']
  },
  'perso_1' : {
    'name' : 'Boateng',
    'picture' : 'img/boateng.jpg',
    'texte' : ['Hey Lionel cava ? ta pas l\'air fiere d\'avoir perdu la Coupe du Monde HAHA!','Je ne vois pas du tout de quoi tu parles la seul chose que je vois c\'est que je suis champon du monde','Ouh de quoi tu parles ? petit bonhomme']
  }
}
