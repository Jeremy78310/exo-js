var data = {
  'perso_0' : {
    'name' : 'Kira',
    'picture' : 'img/Kira.jpg',
    'picture02':'img/Kira1.jpg',
    'texte' : ['Je suis la justice! Je protège les innocents et ceux qui craignent le mal. Im celui qui deviendra le dieu d\'un monde nouveau que tout le monde veut !',' Pour gagner, vous devez attaquer','Écoutez ceci: Je ne suis pas seulement Kira, mais je suis aussi Dieu du nouveau monde!']
  },
  'perso_1' : {
    'name' : 'Ryuk',
    'picture' : 'img/Ryukkk.jpg',
    'picture03': 'img/ryukk.png',
    'texte' : ['Les humains sont intéressants.','Pour moi les pommes sont comme les cigarettes et l\'alcool pour les humains.', 'Je ne vous ai pas choisi. Ne voyez-vous pas que ce soit tout juste un accident?']
  }
}
