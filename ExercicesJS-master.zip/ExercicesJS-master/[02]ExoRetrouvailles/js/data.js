var data = {
  'perso_0' : {
    'name' : 'Chouwi',
    'picture' : 'img/chouwi.jpg',
    'texte' : ['Brouuuuwhaaaaa','Drrrriiiitch','Hinnn Wouaaa']
  },
  'perso_1' : {
    'name' : 'Archibalde',
    'picture' : 'img/archi.jpg',
    'texte' : ['Grand père, c\'est moi!','J\'aime les pâttes moi aussi','Pff nimporte quoi!']
  }
}
